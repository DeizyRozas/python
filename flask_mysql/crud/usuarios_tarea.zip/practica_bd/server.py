from crear_usuarios_app import app
from crear_usuarios_app.controllers import controlador

if __name__=="__main__":
    app.run(debug=True)